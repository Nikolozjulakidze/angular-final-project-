import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { EatDrinkComponent } from './eat-drink/eat-drink.component';
import { EventsComponent } from './events/events.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { DetailsComponent } from './details/details.component';
import { GalleryComponent } from './gallery/gallery.component';


const routes: Routes = [
  {path:"",component:HomePageComponent},
  {path:"eat-drink",component:EatDrinkComponent},
  {path:"events",component:EventsComponent},
  {path:"about",component:AboutComponent},
  {path:"details/:title",component:DetailsComponent},
  {path:"gallery",component:GalleryComponent},
  {path:"contact",component:ContactComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
