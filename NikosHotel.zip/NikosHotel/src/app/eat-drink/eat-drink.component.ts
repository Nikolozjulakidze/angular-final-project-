import { Component } from '@angular/core';

@Component({
  selector: 'app-eat-drink',
  templateUrl: './eat-drink.component.html',
  styleUrl: './eat-drink.component.css'
})
export class EatDrinkComponent {

}
