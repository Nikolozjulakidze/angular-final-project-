import { Component } from '@angular/core';
import { HttpService } from '../shared/http.service';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrl: './gallery.component.css'
})
export class GalleryComponent {
  Products = [
    {
    title:'The Biltmore Tbilisi HotelOpens in new window',
    location:"Mtatsminda , Tbilisi City",
    images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/76593799.jpg?k=aacd9eb01c196b519c24315746522e13512dbba8caba2421257fca426cabf673&o=&hp=1',
    active:true,
    stars:5
    },

    {
      title:' Radisson Blu Iveria Hotel',
      location:"$19.99",
      images:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSs8U4FlVO_mbUBz-oNpiIx6WpTUq8BLq4uJQ&s',
      active:true,
      stars:5
      },

      {
        title:'Hilton Garden Inn Tbilisi Chavchavadze',
        price:"$19.99",
        images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/484107103.jpg?k=840c0d905aba492540038df23df706c21a679ab7617b3492a4544933cecc2624&o=&hp=1',
        active:true,
        stars:5
        },

        {
          title:'Sheraton Grand Tbilisi Metechi Palace',
          price:"$19.99",
          images:'https://cache.marriott.com/content/dam/marriott-renditions/TBSSI/tbssi-exterior-8483-hor-wide.jpg?output-quality=70&interpolation=progressive-bilinear&downsize=1336px:*',
          active:true,
          stars:5
          },

           {
          title:'Panorama Black Sea View & ApartHotel Batumi',
          location: 'New Boulevard , Batumi',
          images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/535728614.jpg?k=cd3813f3fed204105c6430231faa3d18f12614beec8baa88a5f7bfed9334de7c&o=&hp=1',
          active:true,
          city:"batumi",
          stars:4
          },

          {
            title:'Batumi Central Apart Hotel Orbi ',
            location: 'New Boulevard , Batumi',
            images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/575050018.jpg?k=c59c0d12e5fadad5737513358eac5ae83554c87f2e0d64c4aa90c34a37009d40&o=&hp=1',
            active:true,
            city:"batumi",
            stars:4
            },


            {
              title:'Sunshine Apartments Aliance Palace',
              location: 'Sherif Khimshiashvili Street, 6000 Batumi, Georgia',
              images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/451361593.jpg?k=3590dcbd7bc44322a89e67ebdc412875037b56efa7bc36c8a52d38831f3e1c33&o=&hp=1',
              active:true,
              city:"batumi",
              stars:4
              },


              {
                title:'Alliance Palace By Marriott Aparthotel',
                location: ' 5 Sherif Khimshiashvili Street, 6000 Batumi, Georgia',
                images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/538987825.jpg?k=eebfb5f7417358aacca84845144d463443d6dbe54b84f2e85a210732a62327cc&o=&hp=1',
                active:true,
                city:"batumi",
                stars:5
                },


                {
                  title:'Lopota Lake Resort & Spa',
                  location: ' Lopota, 2200 Napareuli, Georgia ',
                  images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/571711182.jpg?k=b46afce95f45595f956cd1d34fa6c9a8147735528d0646c7e66523f8b4835168&o=&hp=1',
                  active:true,
                  city:"kaxeti",
                  stars:5
                  },


                  {
                    title:'Holiday Inn Telavi, an IHG Hotel ',
                    location: ' 2 Rustaveli Avenue, 2200 Telavi, Georgia ',
                    images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/333622251.jpg?k=c184285cc23dd0c6ebba6f0430d0d96a7e84e46048830e00a1520235a7f63af8&o=&hp=1',
                    active:true,
                     city:"kaxeti",
                     stars:5
                    },


                    {
                      title:'Royal Palace Hotel, Lagodekhi ',
                      location: ' Vashlovani Street, 7200 Lagodekhi, Georgia ',
                      images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/210807161.jpg?k=61e44568a1ea44465132dcaa9d918474933caa4fec45f975bf1609ca7436396f&o=&hp=1',
                      active:true,
                      city:"kaxeti",
                      stars:5
                      },


                      {
                        title:'Tsinandali Estate, A Radisson Collection Hotel',
                        location: ' Tsinandali village, Tsinandali, Georgia',
                        images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/349710265.jpg?k=9f6feaaa320e38358d3bff011e4343080fc6fad0b583692e00601ee340838fdb&o=&hp=1',
                        active:true,
                        city:"kaxeti",
                        stars:5
                        },


                        {
                          title:'Bakuriani Inn',
                          location: ' 12 Tsakadze street, 1204 Bakuriani, Georgia',
                          images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/478588249.jpg?k=9aa7b715e22fcee4168ca7617799b2ae87c0816f1f320978f645d32a22e328e6&o=&hp=1',
                          active:true,
                          city:"bakuriani",
                          stars:5
                          },

                          {
                            title:'Gudauri Inn',
                            location: ' Daba Gudauri, 4702 Gudauri, Georgia',
                            images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/545518867.jpg?k=b41d86a15f7ea27c2ed429d5372091f60321e8b62199e98a502531b4bbe369b8&o=&hp=1',
                            active:true,
                            city:"gudauri",
                            stars:4
                            },


                            {
                              title:'Atrium New Gudauri by Gudauri Travel ',
                              location: ' Gudauri resort, New Gudauri region RED CO 1 Block Commercial space number 7 - Bar "Gudauri Travel" (1st floor), 4702 Gudauri, Georgia',
                              images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/236586081.jpg?k=caee92bf3c4425c70eb5b9036958e87175a6bfe27c37668d4ff9d76bf04c9995&o=&hp=1',
                              active:true,
                              city:"gudauri",
                              stars:4
                              },

                              {
                                title:'Gogi Resort',
                                location: ' N-House Gogi Ski Resort, 4700 Gudauri, Georgia',
                                images:'https://cf2.bstatic.com/xdata/images/hotel/max1024x768/401248036.jpg?k=0d226bbc21f9eac53a681ea30db2a5369ea9d4c802849c1f410eb57c80d93f06&o=&hp=1',
                                active:true,
                                stars:3
                                },

          
    ]

    public speakerList:string[]=["WhiteBlue", "Gray", "Black","WhiteGreen"]   

  
    filteredProducts: any[] = [];
    showFilteredResults: boolean = false;
  
    filterHotelsByStars(stars: number) {
      this.filteredProducts = this.Products.filter(product => product.stars === stars);
      this.showFilteredResults = true;
    }
  
    resetFilter() {
      this.showFilteredResults = false;
    }

}