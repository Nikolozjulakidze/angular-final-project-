import { Component, HostListener } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css'
})
export class HomePageComponent {
  constructor(private router: Router) { }


  imageUrl = 'https://static.wixstatic.com/media/9c608a_843cbc1101c646b09ff112d0b0ef3c4c.jpg/v1/fill/w_1349,h_630,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/9c608a_843cbc1101c646b09ff112d0b0ef3c4c.jpg';
  zoomScale = 1;



  @HostListener('window:scroll', ['$event'])
  onWindowScroll() {
    const scrollPosition = window.scrollY;
    this.zoomScale = 1 + scrollPosition / 1000; 
  }

  onImageLoad() {
    
  }

  gotoeatpage() {
    this.router.navigate(['/eat-drink']); 
  }

  gotoAboutPage()
  {
    this.router.navigate(['/about']); 
  }

  gotoEventsPage()
  {
    this.router.navigate(['/events']);  
  }

  gotoContactPage()
  {
    this.router.navigate(['/contact']);   
  }

  gotoGalleryPage()
  {
    this.router.navigate(["/gallery"])
  }
}
